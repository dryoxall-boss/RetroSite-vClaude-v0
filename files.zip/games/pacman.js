// Minimal Pac-Man
